import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'dart:async';

class StaticTimeDisplay extends StatefulWidget {

  const StaticTimeDisplay({super.key});

  @override
  State<StaticTimeDisplay> createState() => _StaticTimeDisplayState();
}

class _StaticTimeDisplayState extends State<StaticTimeDisplay> {
  String _timeString = '';
  String _dateString = '';
  String _weekDayString = '';
  late Timer _timer; // Timer Object to update time periodically

  

  String _getTime() { // This is a formating function
    final DateTime now = DateTime.now();
    final String formattedTime = DateFormat('hh : mm').format(now);
    final String formattedDate = DateFormat('dd MMM yyyy').format(now);
    final String weekDay = DateFormat('EEEE').format(now);
    setState(() {
      _timeString = formattedTime;
      _dateString = formattedDate;
      _weekDayString = weekDay;
    });
    return formattedTime;
  }

  @override
  void initState() {
    super.initState();
    _timeString = _getTime();
    _timer = Timer.periodic(const Duration(seconds: 1), (Timer t) => _getTime());
  }

  @override
  void dispose(){
    _timer.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
           const Icon(Icons.access_time_filled,size: 90,),

           const SizedBox(height: 10,),

          Text(
            _timeString,
            style: TextStyle(
              fontFamily: 'Outfit',
              fontSize: 100,
              fontWeight: FontWeight.w400,  // Bold weight
              color: Theme.of(context).colorScheme.onSurface
            ),
          ),
          const SizedBox(height: 5.5),

          Text(
            _weekDayString,
            style: TextStyle(
              fontFamily: 'Outfit',
              fontSize: 40,
              fontWeight: FontWeight.w200,  // Medium weight
              color: Theme.of(context).colorScheme.onSurface,
            ),
          ),
          const SizedBox(height: 5),

          Text(
            _dateString,
            style: TextStyle(
              fontFamily: 'Outfit',
              fontSize: 24,
              fontWeight: FontWeight.w100,  // Medium weight
              color: Theme.of(context).colorScheme.onSurface
            ),
          ),
        ],
      ),
    );
  }
}