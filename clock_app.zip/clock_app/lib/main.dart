import 'package:minimal_clock/pages/other_themes/theme1.dart';
import 'package:minimal_clock/pages/other_themes/theme2.dart';
import 'package:minimal_clock/pages/other_themes/theme3.dart';
import 'package:minimal_clock/pages/othertheme.dart';
import 'package:minimal_clock/theme/theme_provider.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:minimal_clock/pages/home_page.dart';
import 'package:provider/provider.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();

  SystemChrome.setPreferredOrientations([
    DeviceOrientation.landscapeLeft,
    DeviceOrientation.landscapeRight]
  );

  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    systemNavigationBarColor: Colors.transparent,
    systemNavigationBarContrastEnforced: false,
    systemNavigationBarDividerColor: Colors.transparent,
    systemStatusBarContrastEnforced: false,
    systemNavigationBarIconBrightness: Brightness.dark,
    statusBarIconBrightness: Brightness.dark,
    statusBarBrightness: Brightness.light,
  ));

  SystemChrome.setEnabledSystemUIMode(
    SystemUiMode.immersiveSticky,
    overlays: [SystemUiOverlay.top]
  );

  runApp(ChangeNotifierProvider(create: (context) => ThemeProvider(),
  child: const MyApp(),));
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {

    return Consumer<ThemeProvider>(
      builder: (context, themeProvider, _){
        final isDark = themeProvider.themeData.brightness == Brightness.dark;
      

        return AnnotatedRegion<SystemUiOverlayStyle>(
          value: SystemUiOverlayStyle(
            systemNavigationBarColor: Colors.transparent,
            systemNavigationBarIconBrightness: isDark? Brightness.light : Brightness.dark, 
            statusBarIconBrightness: isDark? Brightness.light : Brightness.dark,
            statusBarBrightness: isDark? Brightness.dark : Brightness.light
          ),
          child: MaterialApp(
            debugShowCheckedModeBanner: false,
            theme: themeProvider.themeData, // Use the theme from provider
            // Defining Routes
            initialRoute: '/',
            routes: {
              '/' : (context) => const HomePage(),
              '/other-themes' : (context) => OtherThemesPage(),
              '/Theme1' : (context) => const Theme1(),
              '/Theme2' : (context) => const Theme2(),
              '/Theme3' : (context) => const Theme3(),
            },
          ),
        );
      }
    );
  }
}